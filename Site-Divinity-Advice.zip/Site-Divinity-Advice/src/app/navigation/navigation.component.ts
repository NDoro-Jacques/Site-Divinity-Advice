import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  navigation = {
    home: 'Accueil',
    homeLink: 'accueil',
    portfolio: 'Portfolio',
    portfolioLink: 'portfolio',
    services: 'Services',
    servicesLink: 'services',
    team: 'Team',
    teamLink: 'team',
    about: 'A propos',
    aboutLink: 'a-propos',
    contact: 'Contact',
    contactLink: 'contact'
  };

  constructor() { }

  ngOnInit() {
  }

}
