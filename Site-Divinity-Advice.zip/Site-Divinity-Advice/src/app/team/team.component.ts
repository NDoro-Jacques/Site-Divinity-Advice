import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {

  team = {
    title: 'Team',
    subtitle: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dignissimos debitis.',
    teams: [
      {
        teamImage: 'team 1-01.jpg',
        teamTitle: 'Divinity Advice',
        teamJob: 'Développeur'
      },
      {
        teamImage: 'team 2-01.jpg',
        teamTitle: 'Divinity Advice',
        teamJob: 'Développeur'
      },
      {
        teamImage: 'team 3-01.jpg',
        teamTitle: 'Divinity Advice',
        teamJob: 'Digital Marketeur'
      },
      {
        teamImage: 'team 1-01.jpg',
        teamTitle: 'Divinity Advice',
        teamJob: 'Infographe'
      }
    ]
  };

  constructor() { }

  ngOnInit() {
  }

}
