import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  contact = {
    title: 'Contact',
    subtitle: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dignissimos debitis.',
    submitButtonText: 'Envoyer message',
    localisation: 'Localisation',
    localisationText: 'Université de Cocody, Abidjan, Côte d\'Ivoire',
    email: 'E-mail',
    emailText: 'divinity-advice@gmail.com',
    contact: 'Contact',
    contactText: '(+225) 01 02 03 04'
  };

  constructor() { }

  ngOnInit() {
  }

}
