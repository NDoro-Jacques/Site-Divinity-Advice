import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit {

  portfolio = {
    title: 'Portfolio',
    subtitle: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dignissimos debitis.',
    text: 'Voir le projet',
    image: '1.jpg',
    counters: [
      {
        icon: 'calendar',
        number: '30',
        text: 'Mois d\'existence'
      },
      {
        icon: 'users',
        number: '80',
        text: 'Membres actifs'
      },
      {
        icon: 'files',
        number: '12000',
        text: 'Projets réalisés'
      },
      {
        icon: 'heart',
        number: '43',
        text: 'Clients satisfaits'
      }
    ]
  };

  constructor() { }

  ngOnInit() {
  }

}
