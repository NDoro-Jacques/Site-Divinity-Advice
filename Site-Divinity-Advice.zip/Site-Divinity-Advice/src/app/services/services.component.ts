import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  services = {
    title: 'Services',
    subtitle: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy',
    items: [
      {
        itemColor: 'color-1',
        itemIcon: 'code',
        itemTitle: 'Développement web',
        itemDescription: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.'
      },
      {
        itemColor: 'color-2',
        itemIcon: 'color-pallet',
        itemTitle: 'Graphisme/Design',
        itemDescription: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.'
      },
      {
        itemColor: 'color-3',
        itemIcon: 'stats-up',
        itemTitle: 'Gestion de projets',
        itemDescription: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.'
      },
      {
        itemColor: 'color-4',
        itemIcon: 'layers',
        itemTitle: 'Formations',
        itemDescription: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.'
      },
      {
        itemColor: 'color-5',
        itemIcon: 'tab',
        itemTitle: 'Développement d\'applications',
        itemDescription: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.'
      },
      {
        itemColor: 'color-6',
        itemIcon: 'laptop',
        itemTitle: 'Digital Marketing',
        itemDescription: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut.'
      }
    ]
  };

  constructor() { }

  ngOnInit() {
  }

}
